var initialLocation;
var browserSupportFlag =  new Boolean();
var map;
var lo,lat;
var marker;
var timezoneID;
var polyline;
var marker;

function getTimezone(jData) {
  timezoneID=jData.timeZoneId;
//  console.log("get timezone");
  document.getElementById('timeZone').value=timezoneID;
}

function ra_de(deg) {
var pi = Math.PI;
var ra_de = deg *(180/pi);
return ra_de;
}

function de_ra(deg) {
var pi = Math.PI;
var de_ra = deg * (pi/180);
return de_ra;
}

function drawQibla(lat, long) {
    var flightPlanCoordinates=new Array();
    var makalng=de_ra(39.823333);
    var makalat=de_ra(21.423333);
    var mylat=de_ra(lat);
    var mylng=de_ra(long);
    var d=Math.acos(Math.sin(mylat)*Math.sin(makalat)+Math.cos(mylat)*Math.cos(makalat)*Math.cos(mylng-makalng));
    
    var i=0;

    for (i=0; i<50; i++){ 
      var fraction=i/(50 * 1.0);
      var A = Math.sin((1-fraction) * d )/Math.sin(d);
      var B = Math.sin(fraction * d )/Math.sin(d);
      var x = A * Math.cos(mylat)*Math.cos(mylng) +  B * Math.cos(makalat) * Math.cos(makalng);
      var y = A*Math.cos(mylat)*Math.sin(mylng) +  B*Math.cos(makalat)*Math.sin(makalng);
      var z = A*Math.sin(mylat) +  B*Math.sin(makalat);
      var l= ra_de(Math.atan2(z,Math.sqrt(Math.pow(x,2)+Math.pow(y,2))));
      var ln= ra_de(Math.atan2(y,x));
      flightPlanCoordinates[i]= new mapkit.Coordinate(l, ln);
      //console.log(l);
    }

    flightPlanCoordinates[i]=new mapkit.Coordinate(21.423333,39.823333);

    var style = new mapkit.Style({
      lineWidth: 2,
      lineJoin: "round",
      strokeColor: "red"
    });
    
    polyline = new mapkit.PolylineOverlay(flightPlanCoordinates, { style: style });

    map.addOverlay(polyline);

}

function initialize() {
    
    //If a location is already selected
    if(document.getElementById('latitude').value !=0)
    {
        //initialLocation = new google.maps.LatLng(document.getElementById('latitude').value,document.getElementById('longitude').value);

        map.setCenterAnimated(new mapkit.Coordinate(document.getElementById('latitude').value,document.getElementById('longitude').value));

        
       // map.setCenter(initialLocation);
       // myFunction(document.getElementById('latitude').value,document.getElementById('longitude').value);
        drawQibla(document.getElementById('latitude').value,document.getElementById('longitude').value);
	//console.log("0000");
    }
    
    // Try W3C Geolocation method (Preferred)
   
else{
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(foundPosition,positionError, { enableHighAccuracy: false, maximumAge: 60000, timeout: 10000 });
  }else{
    console.log("no navigator");
  }
}
initMap();
 loadXMLDoc();
}

function foundPosition(position){
  initialLocation = new mapkit.Coordinate(position.coords.latitude,position.coords.longitude);
      map.setCenterAnimated(initialLocation);
      myFunction(position.coords.latitude,position.coords.longitude);
      drawQibla(position.coords.latitude,position.coords.longitude);
}
function positionError(error){
  initialLocation = new mapkit.Coordinate(24.5247,39.5692);
      map.setCenterAnimated(initialLocation);
      myFunction(24.5247,39.5692);
      drawQibla(24.5247,39.5692);
}

function initMap() {
 //  console.log("init map");
   /*map = new google.maps.Map(document.getElementById('map_canvas'), {
   center: {lat: -34.397, lng: 150.644},
   zoom: 6,
   mapTypeId: google.maps.MapTypeId.ROADMAP

   });*/
   console.log(location.hostname);
   var mapkey = "";
   if(location.hostname == "www.five-tech.com")
     mapkey = "eyJhbGciOiJFUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjMyUDM2UVVGS1cifQ.eyJpc3MiOiIzTVc1NzU5WkQ3IiwiaWF0IjoxNTg4NDM5NTE5LCJleHAiOjM4MDg4MzMxMTksIm9yaWdpbiI6Imh0dHBzOi8vd3d3LmZpdmUtdGVjaC5jb20ifQ.w3nXli9-xpWQj8Sm-yY6JwRzR1bSpWb3kfIa60HgAa5nTwFmn03Wf8pSugRgfObIvXb7ERqVt3W0uQxTNfJ-1A";
   else if(location.hostname == "www.moonsighting.com")
     mapkey = "eyJhbGciOiJFUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjMyUDM2UVVGS1cifQ.eyJpc3MiOiIzTVc1NzU5WkQ3IiwiaWF0IjoxNTg4NDM5NTE5LCJleHAiOjM4MDg4MzMxMTksIm9yaWdpbiI6Imh0dHBzOi8vd3d3Lm1vb25zaWdodGluZy5jb20ifQ.S52tIASn3JNmFTNu-7BW2F_wijnLeXYzobpGbAV1F07SiWABTHBHDXwG7rXbAU9eU3KvW8bgcfKz_QQMb8gstQ";
   else if(location.hostname == "moonsighting.com")
     mapkey = "eyJhbGciOiJFUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjMyUDM2UVVGS1cifQ.eyJpc3MiOiIzTVc1NzU5WkQ3IiwiaWF0IjoxNjIxNDk5OTg5LCJleHAiOjE2NTMwMDQ4MDAsIm9yaWdpbiI6Imh0dHBzOi8vbW9vbnNpZ2h0aW5nLmNvbS8ifQ.9fZjiRoYuyF9J4NciQGK2VFu0ki47hwbAoaPwztgyBjc3FB7cS8a16C9ihW3cS5ZNCDGr3-hBlSLhx2hFWtvbQ";
    else if(location.hostname == "localhost")
      mapkey = "eyJhbGciOiJFUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjI2S0Q4Q1Y0VDgifQ.eyJpc3MiOiIzTVc1NzU5WkQ3IiwiaWF0IjoxNTg4NDM5NTE5LCJleHAiOjM4MDg4MzMxMTl9.vCdARt6oyqWbasx4SOYYCSPomheU1spm9n9FowihIfWqDiOhd7BfKqtQhhO7zvWnIOBc3UQEM07OXMwoPyFeBQ";
   mapkit.init({
    authorizationCallback: function(done) {
        done(mapkey);
     }
    });
    const coordinates = new mapkit.Coordinate(-34.397, 150.644);
    var region = new mapkit.CoordinateRegion(
      new mapkit.Coordinate(-34.397, 150.644),
      new mapkit.CoordinateSpan(10, 10)
      );
    map = new mapkit.Map("map_canvas", {
      showsUserLocation: true,
      showsUserLocationControl: true,
      region: region,
      center: coordinates
     });
  // initialize();
}

function myFunction(latitude,longitude) {
//    console.log("myFunction"); 
    document.getElementById('latitude').value=latitude;
    document.getElementById('longitude').value=longitude;
    
    //timezoneService(latitude,longitude);
    timezoneID = Intl.DateTimeFormat().resolvedOptions().timeZone;
    document.getElementById('timeZone').value=timezoneID;
    var rightNow = new Date();
    
  //    var zone=-1 * rightNow.getTimezoneOffset()/60;
    
    
    
 //   if(zone >0)
 //       zone="+" + zone;
 //   document.getElementById('timeZone').value=zone;
    if(document.getElementById('year').value==0)
          document.getElementById('year').value=rightNow.getFullYear();
    
    /////////8888
    
    /*
    marker = new google.maps.Marker({
                                    position: new google.maps.LatLng(latitude, longitude), 
                                    map: map, 
                                    draggable:true,
                                    animation: google.maps.Animation.DROP
                                    });*/
    marker = new mapkit.MarkerAnnotation(new mapkit.Coordinate(latitude, longitude), {
      data: { /* Custom data here */ },
      color: 'red'
      });
      marker.draggable = true;
      //marker.selected = true;
      map.addAnnotation(marker);
   /* google.maps.event.addListener(marker, 'dragend', function(event) {
                                  placeMarker(event.latLng);
                                  });*/
    
    marker.addEventListener("drag-end", dragEnd);
    loadXMLDoc();
    
    
    ////9999

    
}

function dragEnd(){
  console.log('placeMarker');
      document.getElementById('latitude').value=marker.coordinate.latitude;
      document.getElementById('longitude').value=marker.coordinate.longitude;

    //timezoneService(marker.coordinate.latitude,marker.coordinate.longitude);
    document.getElementById('timeZone').value = tzlookup(marker.coordinate.latitude,marker.coordinate.longitude);
    if(polyline){
      map.removeOverlay(polyline);
      }

   //polyline.setMap(null);
    drawQibla(marker.coordinate.latitude,marker.coordinate.longitude);
    loadXMLDoc();
}
/*
function handleNoGeolocation(errorFlag) {
    var infowindow = new google.maps.InfoWindow();
    var siberia = new google.maps.LatLng(60, 105);
    var newyork = new google.maps.LatLng(40.69847032728747, -73.9514422416687);

    if (errorFlag == true) {
        initialLocation = newyork;
        contentString = "Error: The Geolocation service failed. \r\n Drag and drop the pin to your location";
        myFunction(40.719160,-74.001846);
	drawQibla(40.719160,-74.001846);
    } else {
        initialLocation = siberia;
        contentString = "Error: Your browser doesn't support geolocation. Are you in Siberia?";
    }
    map.setCenter(initialLocation);
    infowindow.setContent(contentString);
    infowindow.setPosition(initialLocation);
    infowindow.open(map);
}*/

function changeSelection()
{
	if(document.getElementById('method').selectedIndex == 3)
		{
		document.getElementById('both').disabled=true;
		document.getElementById('both').checked=false;
		}
	else
		document.getElementById('both').disabled=false;

        loadXMLDoc();
}

function loadXMLDoc(){
  $('#test').fadeIn();

  var lat = document.getElementById('latitude').value;
  var lon = document.getElementById('longitude').value;
  var method = document.getElementById('method').value;
  var year = document.getElementById('year').value;
  var time = document.getElementById('time').value;
  timezoneID = document.getElementById('timeZone').value;
  var both;

  if (document.getElementById('both').checked)
    both = document.getElementById('both').value;
  else
    both = "false";
  var xmlhttp;
  if (window.XMLHttpRequest)
    {// code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp=new XMLHttpRequest();
    }
  else
    {// code for IE6, IE5
        xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
    }
        xmlhttp.onreadystatechange=function()
    {
    if (xmlhttp.readyState==4 && xmlhttp.status==200)
      {
          document.getElementById("myDiv").innerHTML=xmlhttp.responseText;
    $('#test').fadeOut();
      }
    }

    var url = window.location.href;
    url = url.substring(0, url.lastIndexOf("/") + 1);
    xmlhttp.open("GET",url + "praytable.php?year=" + year + "&tz=" + timezoneID + "&lat=" + lat + "&lon=" + lon +"&method=" + method + "&both=" + both + 
  "&time=" + time ,true);
    xmlhttp.send();
}

